package com.stayeasy.dao;

public class ReviewDao {

}
