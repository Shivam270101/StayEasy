package com.stayeasy.entity;

public enum UserType {
ROLE_USER,ROLE_OWNER
}
