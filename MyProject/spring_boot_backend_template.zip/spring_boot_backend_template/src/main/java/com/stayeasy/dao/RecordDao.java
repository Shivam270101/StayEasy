package com.stayeasy.dao;

public class RecordDao {

}
