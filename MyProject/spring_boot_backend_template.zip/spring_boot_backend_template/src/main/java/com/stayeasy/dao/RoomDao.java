package com.stayeasy.dao;

public class RoomDao {

}
